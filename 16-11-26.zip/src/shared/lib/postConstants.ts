export const CATEGORY_GRADIENTS: Record<string, string> = {
  Technology: "from-indigo-950 to-indigo-900",
  Design: "from-pink-950 to-pink-900",
  Marketing: "from-amber-950 to-amber-900",
  Writing: "from-emerald-950 to-emerald-900",
  Education: "from-blue-950 to-blue-900",
  Finance: "from-teal-950 to-teal-900",
  Health: "from-green-950 to-green-900",
  Legal: "from-violet-950 to-violet-900",
  "Home & Living": "from-orange-950 to-orange-900",
};

export const CATEGORY_COLORS: Record<string, string> = {
  technology: "#6366f1",
  design: "#ec4899",
  marketing: "#f59e0b",
  writing: "#10b981",
  education: "#3b82f6",
  finance: "#14b8a6",
  healthcare: "#22c55e",
  history: "#a855f7",
  legal: "#8b5cf6",
  "home & living": "#f97316",

  // Additional categories
  home_services: "#f97316",
  repairs: "#dc2626",
  moving: "#0ea5e9",
  personal: "#a855f7",
  transport: "#06b6d4",
  automotive: "#ef4444",
  events: "#f43f5e",
  photography: "#d946ef",
  video: "#e11d48",
  music: "#8b5cf6",
  fitness: "#84cc16",
  beauty: "#f472b6",
  food: "#fb923c",
  cooking: "#f97316",
  shopping: "#eab308",
  travel: "#0ea5e9",
  tourism: "#14b8a6",
  business: "#64748b",
  consulting: "#6366f1",
  freelancing: "#10b981",
  jobs: "#2563eb",
  accounting: "#0891b2",
  real_estate: "#ca8a04",
  construction: "#78716c",
  repair: "#dc2626",
  plumbing: "#0284c7",
  electrical: "#facc15",
  cleaning: "#06b6d4",
  security: "#475569",
  delivery: "#7c3aed",
  logistics: "#9333ea",
  childcare: "#fb7185",
  pets: "#a16207",
  gardening: "#16a34a",
  sports: "#ea580c",
  gaming: "#7c3aed",
  entertainment: "#db2777",
  social: "#e11d48",
  community: "#0d9488",
  other: "#71717a",
};

export function getCategoryPresentation(category: string) {
  const normalizedCategory = category.trim().toLowerCase();
  return {
    label: category
      .replace(/[_-]+/g, " ")
      .replace(/\b\w/g, (letter) => letter.toUpperCase()),
    color: CATEGORY_COLORS[normalizedCategory] ?? "#FF3F3F",
  };
}

export const POST_STATUS_STYLE: Record<string, string> = {
  live: "text-emerald-400 bg-emerald-950/40 border-emerald-800/50",
  in_progress: "text-blue-400 bg-blue-950/40 border-blue-800/50",
  completed: "text-zinc-500 bg-zinc-900 border-zinc-800",
  expired: "text-amber-400 bg-amber-950/40 border-amber-800/50",
  cancelled: "text-red-400 bg-red-950/30 border-red-800/40",
};
