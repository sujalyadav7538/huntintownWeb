import {
  Trees,
  Plus,
  Footprints,
  LucideIcon,
  User,
  Compass,
  UserRound,
  BowArrow,
  Home,
} from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";

import { getUserId } from "@/src/shared/utils";
import UserAvatar from "@/src/shared/components/UserAvatar";

type Tab =
  | "landing"
  | "explore"
  | "activity"
  | "responses"
  | "login"
  | "profile"
  | "feed"
  | "dashboard"
  | "messaging";

interface MobileBottomNavigationProps {
  activeTab: string;
  setActiveTab: (tab: Tab) => void;
  isAuthenticated: boolean;
  onCreatePost: () => void;
  currentUser?: {
    _id: string;
    name: string;
    avatar?: string;
  };
}

interface NavItem {
  id: Tab;
  label: string;
  icon: LucideIcon;
  auth?: boolean;
}

const NAV_ITEMS: NavItem[] = [
  { id: "landing", label: "Home", icon: Home },
  { id: "explore", label: "Explore", icon: BowArrow },
  { id: "activity", label: "Activity", icon: Footprints, auth: true },
  { id: "profile", label: "Profile", icon: User, auth: true },
];

export default function MobileBottomNavigation({
  activeTab,
  setActiveTab,
  isAuthenticated,
  onCreatePost,
  currentUser,
}: MobileBottomNavigationProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const profileId = getUserId(currentUser);

  const isActive = (item: NavItem) =>
    item.id === "profile"
      ? location.pathname.startsWith("/profile")
      : item.id === activeTab ||
        (item.id === "activity" && activeTab === "dashboard") ||
        (item.id === "explore" && activeTab === "feed");

  const handleNavigation = (item: NavItem) => {
    if (item.auth && !isAuthenticated) {
      setActiveTab("login");
      return;
    }

    if (item.id === "profile") {
      if (profileId) navigate("/profile");
      return;
    }

    setActiveTab(item.id);
  };

  const renderNavItem = (item: NavItem) => {
    const active = isActive(item);
    const isProfile = item.id === "profile";
    const label = isProfile && !isAuthenticated ? "Sign In" : item.label;

    return (
      <button
        key={item.id}
        type="button"
        onClick={() => handleNavigation(item)}
        aria-label={label}
        aria-current={active ? "page" : undefined}
        className={`flex flex-col items-center gap-0.5 px-3 py-2.5 transition ${
          active ? "text-[#FF3F3F]" : "theme-text-muted"
        }`}
      >
        {isProfile ? (
          isAuthenticated ? (
            <UserAvatar
              name={currentUser?.name || "Profile"}
              src={currentUser?.avatar}
              className={`h-5 w-5 rounded-full ${
                active ? "ring-1 ring-[#FF3F3F]" : ""
              }`}
              imageClassName="object-cover"
            />
          ) : (
            <UserRound className="h-5 w-5" />
          )
        ) : (
          <item.icon className="h-4 w-4" />
        )}

        <span
          className="inline-flex h-4 items-center justify-center rounded-md px-1.5 text-[8px] font-bold uppercase tracking-wider"
          style={active ? {
            background: "linear-gradient(135deg, rgb(255 255 255 / 18%), rgb(255 255 255 / 3%)), color-mix(in srgb, var(--app-red) 9%, transparent)",
            boxShadow: "0 3px 10px rgb(0 0 0 / 6%)",
            WebkitBackdropFilter: "blur(14px) saturate(160%)",
            backdropFilter: "blur(14px) saturate(160%)",
          } : undefined}
        >
          {label}
        </span>
      </button>
    );
  };

  return (
    <div className="theme-panel fixed inset-x-0 bottom-0 z-40 border-t border-[#232327] bg-[#121214]/95 shadow-xl backdrop-blur-md md:hidden">
      <div className="flex items-center justify-around px-2 pb-safe">
        {NAV_ITEMS.slice(0, 2).map(renderNavItem)}

        <button
          type="button"
          onClick={onCreatePost}
          aria-label="Create post"
          className="theme-btn-accent flex h-10 w-10 items-center justify-center rounded-full"
        >
          <Plus className="h-5 w-5" />
        </button>

        {NAV_ITEMS.slice(2).map(renderNavItem)}
      </div>
    </div>
  );
}