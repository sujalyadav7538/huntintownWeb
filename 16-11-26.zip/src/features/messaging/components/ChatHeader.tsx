import { Conversation } from "@/src/shared/types";
import { ArrowLeft, FileText, MapPin } from "lucide-react";
import UserAvatar from "@/src/shared/components/UserAvatar";
import { useAppSelector } from "@/src/store/hooks";
import { formatLastSeen } from "@/src/shared/lib/presence";
import UserProfileLink from "@/src/shared/components/UserProfileLink";

interface ChatHeaderProps {
  activeConv: Conversation;
  handleBack: () => void;
}

export default function ChatHeader({
  activeConv,
  handleBack,
}: ChatHeaderProps) {
  const { currentUser } = useAppSelector((s) => s.auth);

  const otherParticipant = activeConv.participants.find(
    (p) => p._id !== currentUser?._id,
  );

  return (
    <header className="shrink-0 border-b border-[#1e1e22] bg-[#0c0c0e] px-3 py-3 sm:px-5">
      <div className="flex min-w-0 items-center justify-between gap-3">
        {/* Left */}
        <div className="flex min-w-0 items-center gap-2.5">
          {/* Back */}
          <button
            id="chat-back-mobile"
            type="button"
            onClick={handleBack}
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-zinc-500 transition hover:bg-white/[0.05] hover:text-zinc-200 md:hidden"
            aria-label="Back"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>

          {/* Avatar */}
          <UserProfileLink
            userId={otherParticipant?._id ?? otherParticipant?.id}
            aria-label={`View ${otherParticipant?.name ?? "user"}'s profile`}
            className="relative block shrink-0 rounded-full focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#FF3F3F]"
          >
            <UserAvatar
              name={otherParticipant?.name}
              src={otherParticipant?.avatar}
              className="h-9 w-9 rounded-full border border-[#2b2b30]"
              imageClassName="object-cover"
            />

            {/* Online indicator */}
            <span
              className={`absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border-2 border-[#0c0c0e] ${
                otherParticipant?.isOnline ? "bg-emerald-500" : "bg-zinc-600"
              }`}
            />
          </UserProfileLink>

          {/* User */}
          <div className="min-w-0">
            <UserProfileLink
              userId={otherParticipant?._id ?? otherParticipant?.id}
              className="block truncate text-xs font-bold text-zinc-100 hover:text-[#ff7777] sm:text-sm"
            >
              {otherParticipant?.name || "Unknown"}
            </UserProfileLink>

            <p className="truncate text-[10px] text-zinc-500">
              {otherParticipant?.isOnline
                ? "Online"
                : formatLastSeen(otherParticipant?.lastSeen)}
            </p>
          </div>
        </div>

        {/* Right side */}
        <div className="flex min-w-0 shrink-0 items-center gap-2">
          {/* Post */}
          {activeConv?.post?.title && (
            <div className="hidden min-w-0 max-w-[180px] items-center rounded-lg border border-white/[0.06] bg-white/[0.025] px-2.5 py-1.5 sm:flex">
              <span className="truncate text-[10px] font-medium text-zinc-500">
                {activeConv.post.title}
              </span>
            </div>
          )}

          {/* Address — desktop only */}
          {(otherParticipant as any)?.address && (
            <div className="hidden max-w-[160px] items-center gap-1.5 rounded-lg border border-white/[0.06] bg-white/[0.025] px-2.5 py-1.5 lg:flex">
              <MapPin className="h-3 w-3 shrink-0 text-[#FF3F3F]" />

              <span className="truncate text-[10px] text-zinc-500">
                {(otherParticipant as any).address}
              </span>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
