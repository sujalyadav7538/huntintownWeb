import { useEffect, useState } from "react";
import { useGoogleLogin } from "@react-oauth/google";
import { useLocation } from "react-router-dom";
import type { User } from "@/src/shared/types";
import { apiFetch } from "@/src/shared/lib/api";
import { useSeo } from "@/src/shared/hooks/useSeo";
import { metaEvents } from "@/src/shared/lib/metaPixel";
import type { AuthNavigationState, SignupFormData } from "../types";
import SignInForm from "./SignInForm";
import SignUpForm from "./SignUpForm";
import {
  isPasswordValid,
  PASSWORD_POLICY_MESSAGE,
} from "../passwordPolicy";

import TermsAndConditionsPage from "./TermsAndConditionsPage";
import useRouteScreen from "@/src/shared/hooks/useRouteScreen";

interface LoginPageProps {
  onLogin?: (user: User, token: string) => void;
}

export default function LoginPage({ onLogin }: LoginPageProps) {
  const location = useLocation();
  const authState = location.state as AuthNavigationState | null;
  const authScreen = useRouteScreen("mode");
  const isSignup = authScreen.value
    ? authScreen.value === "signup"
    : authState?.isSignup ?? false;
  const setIsSignup = (signup: boolean) => {
    if (signup !== isSignup) authScreen.open(signup ? "signup" : "signin");
  };
  const [termsAccepted, setTermsAccepted] = useState(
    authState?.termsAccepted === true,
  );
  const termsScreen = useRouteScreen("terms");

  useEffect(() => {
    const navigationState = location.state as AuthNavigationState | null;
    if (!navigationState) return;

    setTermsAccepted(navigationState.termsAccepted === true);
    if (navigationState.formData) setFormData(navigationState.formData);
  }, [location.state]);

  useSeo({ title: isSignup ? "Create an Account" : "Sign In" });

  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState<SignupFormData>({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    ...authState?.formData,
  });

  const [error, setError] = useState("");

  const completeGoogleSignin = async (accessToken: string) => {
    setError("");
    setLoading(true);

    try {
      const res = await apiFetch("/api/user/google", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ access_token: accessToken }),
      });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.message || "Google sign-in failed");
      }

      onLogin?.(data.user, data.access_token ?? "");
      if (data.isNewUser) metaEvents.completeRegistration("google");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Google sign-in failed");
    } finally {
      setLoading(false);
    }
  };

  const googleLogin = useGoogleLogin({
    onSuccess: async (tokenResponse) => {
      await completeGoogleSignin(tokenResponse.access_token);
    },
    onError: () => setError("Google sign-in was cancelled or failed."),
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    setError("");

    if (isSignup && !termsAccepted) return;

    if (!formData.email || !formData.password) {
      setError("Please fill all required fields.");
      return;
    }

    if (isSignup) {
      if (!formData.name.trim()) {
        setError("Please enter your name.");
        return;
      }

      if (!isPasswordValid(formData.password)) {
        setError(PASSWORD_POLICY_MESSAGE);
        return;
      }

      if (formData.password !== formData.confirmPassword) {
        setError("Passwords do not match.");
        return;
      }
    }

    try {
      setLoading(true);

      const endpoint = isSignup ? `/api/user/signup` : `/api/user/signin`;

      const response = await apiFetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          password: formData.password,
          acceptedTerms: isSignup && termsAccepted,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Something went wrong");
      }

      const token: string = data.access_token ?? "";

      if (data.user) {
        onLogin?.(data.user, token);
      } else {
        const fallbackId = data.session?.user?.id || crypto.randomUUID();

        const user: User = {
          _id: fallbackId,
          id: fallbackId,
          name: formData.name || "User",
          avatar: "",
          role: "Member",
          address: "",
        };

        onLogin?.(user, token);
      }

      if (isSignup) metaEvents.completeRegistration("email");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  const openTermsPage = () => termsScreen.open("view");

  if (termsScreen.value) {
    return (
      <TermsAndConditionsPage
        mode="page"
        onClose={termsScreen.close}
        onAccept={() => {
          setTermsAccepted(true);
          termsScreen.close();
        }}
      />
    );
  }

  return (
    <>
    <main className="min-h-dvh  text-white">
      <div className="mx-auto grid min-h-dvh w-full max-w-7xl lg:grid-cols-[minmax(0,1fr)_520px]">
        {/* =====================================================
         * LEFT — Desktop Brand / Context
         * ===================================================== */}
        <section className="relative hidden overflow-hidden border-r border-white/6 lg:flex lg:min-h-dvh lg:flex-col ">
          {/* Background glow */}
          <div className="pointer-events-none absolute -left-32 top-1/4 h-80 w-80 rounded-full bg-[#FF3F3F]/6 blur-3xl" />

          <div className="relative p-12 xl:p-16">
            {/* Brand */}

            {/* Main message */}
            <div className="max-w-lg ">
              <div className="mb-4 flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-[#FF3F3F]" />

                <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500">
                  HuntIn<b className="text-red-600 text-xs">Town</b> Your local
                  community
                </span>
              </div>

              <h1 className="text-5xl font-bold leading-[1.08] tracking-tight text-white xl:text-6xl">
                Find help.
                <br />
                <span className="text-zinc-500">Offer help.</span>
              </h1>

              <p className="mt-4 max-w-md text-base leading-relaxed text-zinc-500">
                Connect with people around you, share what you need, and
                discover how you can help others.
              </p>
            </div>

            {/* Features */}
            <div className="mt-10 flex items-center gap-7 xl:gap-8">
              <div>
                <p className="text-sm font-semibold text-zinc-200">Local</p>

                <p className="mt-1 text-xs text-zinc-600">People around you</p>
              </div>

              <div className="h-8 w-px bg-white/[0.08]" />

              <div>
                <p className="text-sm font-semibold text-zinc-200">Direct</p>

                <p className="mt-1 text-xs text-zinc-600">Chat with people</p>
              </div>

              <div className="h-8 w-px bg-white/[0.08]" />

              <div>
                <p className="text-sm font-semibold text-zinc-200">Community</p>

                <p className="mt-1 text-xs text-zinc-600">
                  Build your reputation
                </p>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="relative px-12 pb-8 xl:px-16">
            <p className="text-[11px] text-zinc-700">© 2026 HuntInTown</p>
          </div>
        </section>

        {/* =====================================================
         * RIGHT — Authentication
         * ===================================================== */}
        <section className="flex min-h-dvh w-full sm:items-center justify-center px-5 py-5 sm:px-8 ">
          <div className="w-full max-w-97.5">
            {/* =================================================
             * Heading
             * ================================================= */}
            <div className="mb-5">
              <h2 className="text-2xl font-bold tracking-tight text-white">
                {isSignup ? "Create your account" : "Welcome back"}
              </h2>

              <p className="mt-2 text-sm text-zinc-500">
                {isSignup
                  ? "Join your local community."
                  : "Sign in to continue to HuntInTown."}
              </p>
            </div>

            {/* =================================================
             * Auth Toggle
             * ================================================= */}
            <div className="mb-7 flex border-b border-white/8">
              <button
                type="button"
                onClick={() => {
                  setError("");
                  setIsSignup(false);
                }}
                className={`relative flex-1 pb-3 text-sm font-semibold transition ${
                  !isSignup ? "text-white" : "text-zinc-600 hover:text-zinc-300"
                }`}
              >
                Sign In
                {!isSignup && (
                  <span className="absolute inset-x-0 bottom-0 h-px bg-[#FF3F3F]" />
                )}
              </button>

              <button
                type="button"
                onClick={() => {
                  setError("");
                  setIsSignup(true);
                }}
                className={`relative flex-1 pb-3 text-sm font-semibold transition ${
                  isSignup ? "text-white" : "text-zinc-600 hover:text-zinc-300"
                }`}
              >
                Sign Up
                {isSignup && (
                  <span className="absolute inset-x-0 bottom-0 h-px bg-[#FF3F3F]" />
                )}
              </button>
            </div>

            {/* =================================================
             * Form
             * ================================================= */}
            {isSignup ? (
              <SignUpForm
                formData={formData}
                onChange={handleChange}
                onSubmit={handleSubmit}
                loading={loading}
                error={error}
                termsAccepted={termsAccepted}
                onTermsAcceptedChange={(accepted) =>
                  accepted ? openTermsPage() : setTermsAccepted(false)
                }
              />
            ) : (
              <SignInForm
                formData={formData}
                onChange={handleChange}
                onSubmit={handleSubmit}
                loading={loading}
                error={error}
              />
            )}

            {/* =================================================
             * Divider
             * ================================================= */}
            <div className="my-6 flex items-center gap-4">
              <div className="h-px flex-1 bg-white/[0.07]" />

              <span className="text-[10px] font-medium uppercase tracking-wider text-zinc-700">
                Or
              </span>

              <div className="h-px flex-1 bg-white/[0.07]" />
            </div>

            {/* =================================================
             * Google
             * ================================================= */}
            <button
              type="button"
              onClick={() => googleLogin()}
              disabled={loading}
              className="
              flex w-full
              items-center justify-center
              gap-3
              rounded-xl
              border border-white/[0.08]
              bg-white/[0.025]
              py-3
              text-sm font-medium
              text-zinc-300
              transition
              hover:bg-white/[0.05]
              hover:text-white
              disabled:opacity-50
            "
            >
              <svg
                width="17"
                height="17"
                viewBox="0 0 48 48"
                aria-hidden="true"
              >
                <path
                  fill="#EA4335"
                  d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                />

                <path
                  fill="#4285F4"
                  d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                />

                <path
                  fill="#FBBC05"
                  d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                />

                <path
                  fill="#34A853"
                  d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                />
              </svg>
              Continue with Google
            </button>

            {/* =================================================
             * Switch Account Type
             * ================================================= */}
            <p className="mt-7 text-center text-xs text-zinc-600">
              {isSignup ? "Already have an account?" : "Don't have an account?"}

              <button
                type="button"
                onClick={() => {
                  setError("");
                  setIsSignup(!isSignup);
                }}
                className="ml-1.5 font-semibold text-zinc-300 transition hover:text-[#FF3F3F]"
              >
                {isSignup ? "Sign In" : "Create Account"}
              </button>
            </p>
          </div>
        </section>
      </div>
    </main>
    </>
  );
}
