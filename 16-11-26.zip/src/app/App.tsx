﻿import { useCallback, useEffect, useLayoutEffect, useMemo, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Post, User } from "@/src/shared/types";

import { useAppDispatch, useAppSelector } from "@/src/store/hooks";
import { login, logout } from "@/src/store/authSlice";
import { socket, setSocketAuth } from "@/src/shared/lib/socket";
import { fetchPosts, clearPosts } from "@/src/store/postsSlice";
import { resetReputation } from "@/src/store/reputationSlice";
import {
  closeCreatePost,
  closeSidePanel,
  handleHideMobileBottomNav,
  handleHideUpperNavigation,
  openSidePanel,
} from "@/src/store/uiSlice";
import { clearPersistedState } from "@/src/store/persistence";
import { resetNotifications } from "@/src/shared/hooks/useNotifications";
import { deletePostThunk, updatePostStatusThunk } from "@/src/store/thunks";
import AppRoutes from "@/src/app/routes/AppRoutes";
import {
  getActiveTabFromPath,
  getPathFromTab,
  isProtectedTab,
} from "@/src/app/routes/tabs";

import Header from "@/src/shared/components/layout/Header";
import SidePanel from "@/src/shared/components/layout/SidePanel";
import MobileBottomNavigation from "@/src/shared/components/layout/MobileBottomNavigation";
import AppErrorNotice from "@/src/shared/components/layout/AppErrorNotice";
import AppDialogProvider from "@/src/shared/components/layout/AppDialogProvider";
import ToastProvider, {
  notifySuccess,
} from "@/src/shared/components/layout/ToastProvider";
import { metaEvents } from "@/src/shared/lib/metaPixel";

export default function App() {
  const dispatch = useAppDispatch();
  const {
    isAuthenticated,
    currentUser,
    token: authToken,
  } = useAppSelector((s) => s.auth);

  // Theme and side panel live in Redux: the theme is persisted across reloads,
  // the panel is deliberately not (see store/persistence.ts).
  const { hideMobileBottomNav, hideUpperNavigation, theme, isSidePanelOpen } =
    useAppSelector((s) => s.ui);

  const location = useLocation();
  const navigate = useNavigate();
  const mainRef = useRef<HTMLElement>(null);
  const isPostRoute = location.pathname.startsWith("/post/");

  // The first load's browser PageView is fired in index.html; here we send its server copy,
  // then track later navigations. Comparing paths keeps StrictMode's double effect from re-firing.
  const lastTrackedPathRef = useRef<string | null>(null);
  useEffect(() => {
    if (lastTrackedPathRef.current === location.pathname) return;
    const isFirstLoad = lastTrackedPathRef.current === null;
    lastTrackedPathRef.current = location.pathname;
    if (isFirstLoad) metaEvents.initialPageView();
    else metaEvents.pageView();
  }, [location.pathname]);

  useLayoutEffect(() => {
    if (
      !location.hash &&
      (location.pathname === "/help" || location.pathname === "/contact")
    ) {
      mainRef.current?.scrollTo({ top: 0, left: 0, behavior: "instant" });
    }
  }, [location.pathname, location.hash, location.key]);

  const activeTab = useMemo(
    () => getActiveTabFromPath(location.pathname),
    [location.pathname],
  );

  const setActiveTab = useCallback(
    (tab: string) => {
      if (isProtectedTab(tab) && !isAuthenticated) {
        navigate("/login", { replace: true });
        return;
      }
      navigate(getPathFromTab(tab));
    },
    [isAuthenticated, navigate],
  );

  // Reflect the persisted theme onto <html data-theme>
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  // Load posts on first authentication — condition in thunk prevents duplicate calls
  useEffect(() => {
    if (isAuthenticated) {
      dispatch(closeSidePanel());
      dispatch(fetchPosts() as any);
    }
  }, [dispatch, isAuthenticated]);

  // Initialize socket connection if user is authenticated
  useEffect(() => {
    const token = authToken;

    if (isAuthenticated && token) {
      if (!socket.connected) {
        setSocketAuth(token);
        socket.connect();
      }
    } else if (!isAuthenticated && socket.connected) {
      socket.disconnect();
    }
  }, [authToken, isAuthenticated]);

  const handleLogin = useCallback(
    (user: User, token: string) => {
      setSocketAuth(token);
      socket.connect();
      dispatch(login({ user, token }));
      dispatch(closeSidePanel());
      navigate("/explore", { replace: true });
    },
    [dispatch, navigate],
  );

  const handleLogout = useCallback(() => {
    resetNotifications();
    setSocketAuth("");
    socket.disconnect();
    dispatch(clearPosts()); // reset fetch lock for next login
    dispatch(resetReputation()); // clear reputation cache for next user
    dispatch(logout());
    dispatch(closeSidePanel());
    clearPersistedState(); // drop the cached feed/chats so nothing leaks to the next user
    navigate("/login", { replace: true });
  }, [dispatch, navigate]);

  const guardedOpenCreatePost = useCallback(() => {
    if (!isAuthenticated) {
      navigate("/login", { replace: true });
      return;
    }
    navigate("/create-post");
  }, [isAuthenticated, navigate]);

  const handleExplorePost = useCallback(
    (postId: string) => {
      navigate(`/post/${encodeURIComponent(postId)}`, {
        state: { returnTo: "/explore" },
      });
    },
    [navigate],
  );

  const handlePostCreated = useCallback(
    (_postId: string) => {
      notifySuccess(
        "Requirement published. Find it under Published requirements on your Dashboard.",
        { label: "View dashboard", onClick: () => navigate("/dashboard") },
      );
      dispatch(closeCreatePost());
      // Explore hides the user's own posts, so show it in the Dashboard instead.
      navigate("/dashboard");
    },
    [dispatch, navigate],
  );

  const handleUpdateStatus = useCallback(
    async (postId: string, status: Post["status"]) => {
      await dispatch(updatePostStatusThunk(postId, status) as any);
      const labels: Record<Post["status"], string> = {
        live: "Requirement reopened.",
        in_progress: "Requirement marked in progress.",
        completed: "Requirement marked complete.",
        expired: "Requirement expired.",
        cancelled: "Requirement cancelled.",
      };
      notifySuccess(labels[status]);
    },
    [dispatch],
  );

  const handleDeleteListing = useCallback(
    async (postId: string) => {
      await dispatch(deletePostThunk(postId) as any);
      notifySuccess("Requirement deleted.");
    },
    [dispatch],
  );

  const handleProfileUpdated = useCallback((_updated: User) => {
    // ProfileView already dispatches updateProfile after successful save.
    // Keep this callback for interface compatibility without duplicate dispatch.
  }, []);

  // Keep mobile bottom nav state deterministic across direct route/tab operations.
  useEffect(() => {
    const isMessagingRoute = location.pathname === "/messaging";
    const hasConversationInUrl = Boolean(
      new URLSearchParams(location.search).get("conversationId"),
    );
    const isProfileEditing =
      location.pathname.startsWith("/profile") &&
      new URLSearchParams(location.search).has("edit");

    if (!isMessagingRoute || !hasConversationInUrl) {
      dispatch(handleHideMobileBottomNav(isProfileEditing || location.pathname.startsWith("/post/")));
      dispatch(handleHideUpperNavigation(isProfileEditing));
    }
  }, [dispatch, location.pathname, location.search]);

  return (
    <AppDialogProvider>
      <ToastProvider>
      <div className="fixed inset-0 flex flex-col  overflow-hidden theme-page-shell antialiased select-text text-zinc-100">
      <div className="flex h-full min-h-0 flex-1 flex-col">
        <Header
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          openCreatePost={guardedOpenCreatePost}
          onLogoutSimulate={handleLogout}
          handleSidePanelOpen={() => dispatch(openSidePanel())}
          hideOnMobile={hideUpperNavigation}
        />

        <main
          ref={mainRef}
          className={`min-h-0 flex-1 w-full mx-auto ${
            hideUpperNavigation ? "pt-0 md:pt-16" : "pt-14 md:pt-16"
          } ${
            isPostRoute
              ? "flex flex-col overflow-hidden lg:px-4"
              : ["messaging"].includes(activeTab)
              ? "flex flex-col overflow-hidden "
              : "overflow-y-auto px-2 pb-16 sm:pb-8 lg:pb-0  sm:px-6  lg:px-4"
          }`}
        >
          <AppRoutes
            isAuthenticated={isAuthenticated}
            setActiveTab={setActiveTab}
            onLogin={handleLogin}
            onLogout={handleLogout}
            onPostRequirement={guardedOpenCreatePost}
            onExplorePost={handleExplorePost}
            onUpdateStatus={handleUpdateStatus}
            onDeleteListing={handleDeleteListing}
            onPostCreated={handlePostCreated}
            onUpdateProfile={handleProfileUpdated}
          />
        </main>

        {/* ── Mobile bottom nav ── */}
        {!hideMobileBottomNav && !isPostRoute && (
          <MobileBottomNavigation
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            isAuthenticated={isAuthenticated}
            currentUser={currentUser}
            onCreatePost={guardedOpenCreatePost}
          />
        )}
      </div>

      <SidePanel
        open={isSidePanelOpen}
        onClose={() => dispatch(closeSidePanel())}
        onLogout={handleLogout}
      />
        <AppErrorNotice />
      </div>
      </ToastProvider>
    </AppDialogProvider>
  );
}
